# Splitting by double newline characters to separate the sections
var = """Clause: 51.(1) Final Payment

Extraction: "On the Engineer's certificate of completion in respect of the works, adjustment shall be made and the balance of account based on the Engineer or the Engineer's representative's certified measurements or Engineer’s certified “contractor’s authorized engineer’s measurements” of the total quantity of work executed by the Contractor upto the date of completion and on the accepted schedule of rates and for extra works on rates determined under Clause 39 of these Conditions shall be paid to the Contractor subject always to any deduction which may be made under these presents and further subject to the Contractor having signed delivered to the Engineer enclosing either a full account in detail of all claims he may have on the Railway in respect of the works or having delivered No Claim Certificate and the Engineer having after the receipt of such account given a certificate in writing that such claims are not covered under excepted matter i.e. Clauses 7(j), 8, 18, 22(5), 39, 43(2), 45 (i)(a), 55, 55 -A(5), 57, 57A, 61(1), 61(2) and 62(1) (i) to xv(B) of Standard General Conditions of Contract or in any Clause (stated as excepted matter) of the Special Conditions of the Contract, that the whole of the works to be done under the provisions of the Contracts have been completed, that they have been inspected by him since their completion and found to be in good and substantial order, that all properties, works and things, removed, disturbed or injured in consequence of the works have been properly replaced and made good and all expenses and demands incurred by or made upon the Railway for or in the respect of damage or loss by from or in consequence of the works, have been satisfied agreeably and in conformity with the contract."

Summary: The completion of performance of the contract is determined by the Engineer's certificate of completion, which certifies that the works have been completed in accordance with the contract and that all claims have been satisfied."""
sections = var.split('\n\n')

# Assign the sections to corresponding variables
# reply = sections[0].strip()  # First part before the first double newline
clause = sections[0].strip()  # Second part between the first and second double newline
explanation = sections[1].strip()  # Third part after the second double newline
summary = sections[2].strip()
# print("Reply:", reply)
print(clause)
print(explanation)
print(summary)
