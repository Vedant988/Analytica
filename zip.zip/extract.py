from PyPDF2 import PdfReader
import os


# Function to extract text from PDF files
def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            text += page.extract_text()
    return text


# Function to save extracted text to a .txt file
def save_text_to_file(text, filename):
    # Define the file path
    filepath = os.path.join("extracted_texts", f"{filename}.txt")

    # Ensure the directory exists
    os.makedirs(os.path.dirname(filepath), exist_ok=True)

    # Write the text to the file
    with open(filepath, "w", encoding="utf-8") as file:
        file.write(text)

    return filepath


# Main function to process PDF files
def main():
    # Directory where PDFs are stored
    pdf_directory = 'C:\\Users\\vedan\\OneDrive\\Desktop\\analyticaa\\app\\data'  # Ensure this is a directory

    # List all PDF files in the specified directory
    pdf_files = [f for f in os.listdir(pdf_directory) if f.endswith('.pdf')]

    if not pdf_files:
        print("No PDF files found in the directory.")
        return

    # Process each PDF file
    for pdf_file in pdf_files:
        pdf_path = os.path.join(pdf_directory, pdf_file)
        print(f"Processing: {pdf_path}")

        # Extract text from the PDF
        pdf_text = get_pdf_text([pdf_path])

        if pdf_text.strip():
            # Save the extracted text to a .txt file
            txt_filename = os.path.splitext(pdf_file)[0]  # Remove the PDF extension for the txt file
            saved_filepath = save_text_to_file(pdf_text, txt_filename)
            print(f"Text extracted and saved to: {saved_filepath}")
        else:
            print(f"No extractable text found in {pdf_file}")


if __name__ == "__main__":
    main()