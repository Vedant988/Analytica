import streamlit as st
from PyPDF2 import PdfReader
from pptx import Presentation
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
import asyncio
import re

from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai

from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain.chains.question_answering import load_qa_chain
from langchain.prompts import PromptTemplate
from dotenv import load_dotenv

load_dotenv('.env')

# Load the API key from the environment variable
genai_api_key = os.getenv('GOOGLE_API_KEY')
if genai_api_key is None:
    raise ValueError("Google API key not found. Please set the GOOGLE_API_KEY environment variable.")

genai.configure(api_key=genai_api_key)

# Function to clean text
def clean_text(text):
    text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with a single space
    text = text.strip()  # Remove leading and trailing spaces
    text = re.sub(r'[^A-Za-z0-9.,!?\'\" ]+', '', text)  # Remove special characters
    return text

# Function to extract text from PDF files
def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            page_text = page.extract_text() or ""
            text += clean_text(page_text)  # Clean extracted text
    return text

# Function to extract text from PPTX files
def get_pptx_text(pptx_docs):
    text = ""
    for pptx in pptx_docs:
        presentation = Presentation(pptx)
        for slide in presentation.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    text += clean_text(shape.text) + "\n"  # Clean extracted text
    return text

# Function to split text into chunks
def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=10000, chunk_overlap=500)
    chunks = text_splitter.split_text(text)
    return chunks

def get_vector_store(text_chunks):
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    vector_store = FAISS.from_texts(text_chunks, embedding=embeddings)
    vector_store.save_local("faiss_index")

# Function to extract keywords and relevant paragraphs from the documents
def extract_keywords_and_paragraphs(user_context, docs):
    keywords = set(user_context.lower().split())  # Basic keyword extraction from user input
    relevant_paragraphs = []

    for doc in docs:
        text = doc.page_content  # Assuming doc.page_content holds the text of the document
        paragraphs = text.split('\n')  # Split into paragraphs
        
        # Check for keywords in each paragraph
        for paragraph in paragraphs:
            if any(keyword in paragraph.lower() for keyword in keywords):
                relevant_paragraphs.append(paragraph.strip())

    return keywords, relevant_paragraphs

# Function to create conversational chain for Hindi
async def get_conversational_chain_hindi():
    prompt_template = """
    Based on the provided context, generate 5 most relevant,precise and short questions in hindi language.
    Context: {context}\n
    Question:

    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.15)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain

# Function to create conversational chain for English
async def get_conversational_chain_english():
    prompt_template = """
    Based on the provided context, generate 5 best most relevant questions and then translate to english and the output should be english.
    Context: {context}\n
    Question:

    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.1)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain

# Function to create conversational chain for Urdu
async def get_conversational_chain_urdu():
    prompt_template = """
    Based on the provided context, generate 5 best most relevant questions and then translate to urdu and the output should be urdu.
    Context: {context}\n
    Question:

    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.2)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain

# Function to create conversational chain for Marathi
async def get_conversational_chain_marathi():
    prompt_template = """
    Based on the provided context, generate 5 best most relevant questions and displayed question should be on be marathi language translated.
    Context: {context}\n
    Question:

    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.2)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain

# Function to create conversational chain for Telugu
async def get_conversational_chain_telugu():
    prompt_template = """
    Based on the provided context, generate 5 best most relevant questions and then translate to telugu and the output should be telugu.
    Context: {context}\n
    Question:

    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.2)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain

# Function to create conversational chain for Sanskrit
async def get_conversational_chain_sanskrit():
    prompt_template = """
    Based on the provided context, generate 5 most relevant,precise and short questions in Sanskrit language (the question should be compoulsory in sanskrit language).
    Context: {context}\n
    Question:

    """
    model = ChatGoogleGenerativeAI(model="gemini-pro", temperature=0.2)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context"])
    chain = load_qa_chain(model, chain_type="stuff", prompt=prompt)
    return chain

# Function to handle user input
async def generate_question(user_context, language):
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    new_db = FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)
    docs = new_db.similarity_search(user_context)

    keywords, relevant_paragraphs = extract_keywords_and_paragraphs(user_context, docs)

    # Display the keywords and relevant paragraphs
    st.write("Keywords Used: ", keywords)
    st.write("Relevant Paragraphs: ", relevant_paragraphs)

    if language == "Hindi":
        chain = await get_conversational_chain_hindi()
    elif language == "English":
        chain = await get_conversational_chain_english()
    elif language == "Urdu":
        chain = await get_conversational_chain_urdu()
    elif language == "Marathi":
        chain = await get_conversational_chain_marathi()
    elif language == "Telugu":
        chain = await get_conversational_chain_telugu()
    elif language == "Sanskrit":
        chain = await get_conversational_chain_sanskrit()

    response = chain({"input_documents": docs, "context": user_context}, return_only_outputs=True)
    st.write("Generated Questions:\n ", response["output_text"])

# Main function
def main():
    st.set_page_config("Multi-language Final")
    st.title("Chat with Multiple PDF and PPTX using Gemini")
    st.header("How To Use this App")
    st.write("1. Upload your PDF and PPTX files using the file uploader.")
    st.write("2. Enter a topic or context for question generation.")
    st.write("3. Choose the language for question generation.")
    st.write("4. Click on the 'Submit & Process' button to process the files and generate questions.")

    user_context = st.text_input("Enter Topic or Context for Question Generation")

    # Language selection
    language = st.selectbox("Select Language for Question Generation", ["Hindi", "English", "Urdu", "Marathi", "Telugu", "Sanskrit"])

    if user_context:
        asyncio.run(generate_question(user_context, language))

    with st.sidebar:
        st.title("Menu:")

        uploaded_files = st.file_uploader("Upload your PDF and PPTX Files and Click on the Submit & Process Button",
                                           accept_multiple_files=True, type=["pdf", "pptx"])
        if st.button("Submit & Process"):
            with st.spinner("Processing..."):
                pdf_files = [file for file in uploaded_files if file.type == "application/pdf"]
                pptx_files = [file for file in uploaded_files if
                              file.type == "application/vnd.openxmlformats-officedocument.presentationml.presentation"]

                raw_text = get_pdf_text(pdf_files) + get_pptx_text(pptx_files)
                text_chunks = get_text_chunks(raw_text)
                get_vector_store(text_chunks)
                st.success("Done")

if __name__ == "__main__":
    main()
