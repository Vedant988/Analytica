import streamlit as st
from PyPDF2 import PdfReader
from pptx import Presentation
from langchain.text_splitter import RecursiveCharacterTextSplitter
import os
import asyncio
import re

from langchain_google_genai import GoogleGenerativeAIEmbeddings
import google.generativeai as genai
from dotenv import load_dotenv

import pinecone

# Load environment variables
load_dotenv('.env')

# Initialize Google and Pinecone
genai_api_key = os.getenv('GOOGLE_API_KEY')
if genai_api_key is None:
    raise ValueError("Google API key not found. Please set the GOOGLE_API_KEY environment variable.")
genai.configure(api_key=genai_api_key)

# Initialize Pinecone
pinecone_api_key = os.getenv("PINECONE_API_KEY")
pinecone_environment = os.getenv("PINECONE_ENVIRONMENT")
pc = pinecone.Pinecone(api_key=pinecone_api_key, environment=pinecone_environment)

# Initialize Pinecone index
index_name = "document-embeddings"
if index_name not in pinecone.list_indexes():
    pinecone.create_index(index_name, dimension=768)
index = pinecone.Index(index_name)

# Function to clean text (handles Hindi characters and other scripts)
def clean_text(text):
    text = re.sub(r'\s+', ' ', text)
    text = text.strip()
    return text

# Function to extract text from PDF files (handles Hindi PDFs)
def get_pdf_text(pdf_docs):
    text = ""
    for pdf in pdf_docs:
        pdf_reader = PdfReader(pdf)
        for page in pdf_reader.pages:
            page_text = page.extract_text() or ""
            cleaned_text = clean_text(page_text)
            text += cleaned_text
    return text

# Function to extract text from PPTX files (handles Hindi text)
def get_pptx_text(pptx_docs):
    text = ""
    for pptx in pptx_docs:
        presentation = Presentation(pptx)
        for slide in presentation.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    cleaned_text = clean_text(shape.text)
                    text += cleaned_text + "\n"
    return text

# Function to split text into chunks
def get_text_chunks(text):
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunks = text_splitter.split_text(text)
    return chunks

# Function to store vector embeddings in Pinecone (Ensure embedding model supports Hindi)
def store_embeddings_in_pinecone(text_chunks):
    # Use a model that supports Hindi embeddings
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")  # Ensure this model supports Hindi text
    for i, chunk in enumerate(text_chunks):
        vector = embeddings.embed(chunk)
        index.upsert([{"id": str(i), "values": vector}])

# Function to search Pinecone for relevant chunks
def search_pinecone(user_context):
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    embedding = embeddings.embed(user_context)
    results = index.query(embedding, top_k=5)
    return [match['id'] for match in results['matches']]

# Main function
def main():
    st.set_page_config("Hindi")
    st.title("Chat with Multiple PDF and PPTX using Pinecone")
    st.write("1. Upload your PDF and PPTX files using the file uploader.")
    st.write("2. Enter a topic or context for question generation.")
    st.write("3. Click on the 'Submit & Process' button.")

    user_context = st.text_input("Enter Topic or Context for Question Generation")

    if user_context:
        with st.sidebar:
            uploaded_files = st.file_uploader("Upload your PDF and PPTX Files", accept_multiple_files=True, type=["pdf", "pptx"])
            if st.button("Submit & Process"):
                pdf_files = [file for file in uploaded_files if file.type == "application/pdf"]
                pptx_files = [file for file in uploaded_files if file.type == "application/vnd.openxmlformats-officedocument.presentationml.presentation"]
                
                raw_text = get_pdf_text(pdf_files) + get_pptx_text(pptx_files)
                text_chunks = get_text_chunks(raw_text)
                store_embeddings_in_pinecone(text_chunks)
                st.success("Embeddings stored in Pinecone.")

                # Perform search
                relevant_chunks_ids = search_pinecone(user_context)
                st.write("Relevant Chunks IDs: ", relevant_chunks_ids)

if __name__ == "__main__":
    main()